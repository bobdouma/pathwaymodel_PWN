# pathwaymodel_PWN
this repository contains the pathway model that was developed for the paper "Development of a pathway model to assess the exposure of European pine trees to pine wood nematode via the trade of wood"
